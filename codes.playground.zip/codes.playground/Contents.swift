import UIKit

var greeting = "Hello, playground"


print ("""
Hello
world!
""")

var age = 23
print("you are \(age)years old and in others\(age) years you will be \(age*2)")
    
print ("Hello All,\rWelocome to swift programming")
      
var programmingLanguage = "swift"
print("My favourate programming language is \(programmingLanguage)")

print("hi",10,12.25)


let WelcomeMessage : String = "Hello!"
print(WelcomeMessage , "All")
      
print("welcome to swift programming")
print("Fall 2021")
print("**********")
print("welcome to swift programming" , terminator : "-" )
print("Fall 2021")

print("The list of numbers are")
print(1,2,3,4,5,6)
print("The new pattern is ")
print(1,2,3,4,5,6, separator: "-")




var httpError = (errorCode : 404 , errorMessage : "Page Not Found")
print(httpError)
print(httpError.errorCode , terminator : ": ")
print(httpError.errorMessage )

var name = ("John","Smith")
var fName = name.0
var lName = name.1
print(fName , terminator : ",")
print(lName)




      





